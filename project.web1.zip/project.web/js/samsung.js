function addNewProduct() {
    // 1. جلب القيم من الحقول 
    const name = document.getElementById('phoneName').value;
    const price = document.getElementById('phonePrice').value;
    let imgUrl = document.getElementById('phoneImg').value;

    // فحص النصوص الفارغة ورسالة التنبيه
    if (name.trim() === '' || price.trim() === '') {
        alert('يرجى إدخال اسم الهاتف والسعر!');
        return;
    }

    // إذا لم يتم وضع رابط للصورة، يتم وضع مسار صورة افتراضي
    if (imgUrl.trim() === '') {
        imgUrl = 'images/default.jpg'; 
    }

    // 2. إنشاء عناصر HTML والكلاس
    const newDiv = document.createElement('div');
    newDiv.className = 'img';

    const newImg = document.createElement('img');
    newImg.src = imgUrl;

    const newP = document.createElement('p');
    newP.innerHTML = name + '<br>' + price; 
    
    // 3. دمج العناصر مع بعضها
    newDiv.appendChild(newImg);
    newDiv.appendChild(newP);

    // 4. إضافة العنصر الجديد إلى حاوية الهواتف 
    const container = document.getElementById('products-container');
    container.appendChild(newDiv);

    // 5. تفريغ الحقول بعد الحفظ بنجاح
    document.getElementById('phoneName').value = '';
    document.getElementById('phonePrice').value = '';
    document.getElementById('phoneImg').value = '';
}

function defaultphone(button){
    
}
