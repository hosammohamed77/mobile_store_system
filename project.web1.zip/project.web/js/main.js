function handleAuth() {
    // إظهار شاشة النجاح البيضاء
    document.getElementById("successBox").style.display = "flex"; 
    
    
    setTimeout(() => {
        window.location.href = "home.html";
    }, 2000);
}